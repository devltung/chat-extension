const API = "https://noname.mydiscussion.net/api";

const loginForm = document.getElementById("loginForm");
const registerForm = document.getElementById("registerForm");
const chatPage = document.getElementById("chatPage");
const messagesDiv = document.getElementById("messages");

function show(el){
  [loginForm, registerForm, chatPage].forEach(e=>e.classList.add("hidden"));
  el.classList.remove("hidden");
}

// chuyển form
goRegister.onclick = ()=>show(registerForm);
goLogin.onclick = ()=>show(loginForm);

// AUTO LOGIN nếu có token
chrome.storage.local.get("token", res=>{
  if(res.token){
    show(chatPage);
    loadMessages();
  }
});

// REGISTER
registerBtn.onclick = async ()=>{
  const res = await fetch(`${API}/register.php`,{
    method:"POST",
    headers:{ "Content-Type":"application/json" },
    body: JSON.stringify({
      username:r_user.value,
      password:r_pass.value
    })
  });
  const data = await res.json();
  alert(data.msg || "Đăng ký xong");
  if(data.ok) show(loginForm);
};

// LOGIN
loginBtn.onclick = async ()=>{
  const res = await fetch(`${API}/login.php`,{
    method:"POST",
    headers:{ "Content-Type":"application/json" },
    body: JSON.stringify({
      username:l_user.value,
      password:l_pass.value
    })
  });
  const data = await res.json();
  if(data.ok){
    chrome.storage.local.set({ token:data.token });
    show(chatPage);
    loadMessages();
  }else{
    alert("Sai tài khoản 😭");
  }
};

// LOAD MESSAGES
async function loadMessages(){
  const { token } = await chrome.storage.local.get("token");
  const res = await fetch(`${API}/messages.php`,{
    method:"POST",
    headers:{ "Content-Type":"application/json" },
    body: JSON.stringify({ token })
  });
  const data = await res.json();

  messagesDiv.innerHTML = "";
  data.forEach(m=>{
  if(m.type === "text"){
    messagesDiv.innerHTML += `
      <div><b>${m.username}:</b> ${m.content}</div>`;
  }

  if(m.type === "image"){
    messagesDiv.innerHTML += `
      <div><b>${m.username}:</b><br>
      <img src="${API}/${m.file_path}" width="150"></div>`;
  }

  if(m.type === "video"){
    messagesDiv.innerHTML += `
      <div><b>${m.username}:</b><br>
      <video src="${API}/${m.file_path}" width="200" controls></video></div>`;
  }

  if(m.type === "file"){
    messagesDiv.innerHTML += `
      <div><b>${m.username}:</b>
      <a href="${API}/${m.file_path}" target="_blank">Tải file</a></div>`;
  }
});

  messagesDiv.scrollTop = messagesDiv.scrollHeight;
}

// SEND MESSAGE
sendBtn.onclick = async ()=>{
  const { token } = await chrome.storage.local.get("token");
  if(!msgInput.value) return;

  await fetch(`${API}/send.php`,{
    method:"POST",
    headers:{ "Content-Type":"application/json" },
    body: JSON.stringify({
      token,
      message:msgInput.value
    })
  });

  msgInput.value="";
  loadMessages();
};

fileInput.onchange = async ()=>{
  const { token } = await chrome.storage.local.get("token");
  const file = fileInput.files[0];
  if(!file) return;

  let type = "file";
  if(file.type.startsWith("image")) type="image";
  if(file.type.startsWith("video")) type="video";

  const formData = new FormData();
  formData.append("token", token);
  formData.append("type", type);
  formData.append("file", file);

  await fetch(`${API}/upload.php`,{
    method:"POST",
    body: formData
  });
  
  loadMessages();
};


// AUTO REFRESH CHAT
setInterval(()=>{
  if(!chatPage.classList.contains("hidden")){
    loadMessages();
  }
},3000);

